<?php
  //Setting up all the URLs for this page//////////
  $homeUrl = (isset($url)) ? $url."Home/main" : "Home/main" ;
  $educationUrl = (isset($url)) ? $url."Home/education" : "Home/education" ;
  $professionUrl = (isset($url)) ? $url."Home/profession" : "Home/profession" ;
  $skillsUrl = (isset($url)) ? $url."Home/skills" : "Home/skills" ;
  $pdfUrl = (isset($url)) ? $url."Home/pdf" : "Home/pdf" ;
  $logoutUrl = (isset($url)) ? $url."Home/logout" : "Home/logout" ;
  $updateProfessionUrl=(isset($url)) ? $url."Home/updateProfession" : "Home/updateProfession";
?>

<!DOCTYPE html>
<html>
<head>
	<title>Resume Maker</title>
    <link rel="stylesheet" type="text/css" href="../style/styleMain.css">
   
</head>
<body>
   <div class="topnav" id="myTopnav">
     <a href="<?php echo $homeUrl;?>" >Home</a>
     <a href="<?php echo $educationUrl;?>" >Education</a>
     <a href="<?php echo $professionUrl;?>" class="active">Profession</a>
     <a href="<?php echo $skillsUrl;?>">Skills</a>
     <a href="<?php echo $pdfUrl;?>" style="background-color: gray;">Get PDF</a>
   </div>
   <a href="<?php echo $logoutUrl;?>" class="tooltip"><span class="tooltiptext">Logout</span>Logout</a>
    <br><br><br>
	<center>
        <h1 style="color: black;">Current Records</h1>
	<div class="container">
      <table class="historyTable">
         <tr>
           <th>jobTitle</th>
           <th>Starting Date</th>
           <th>Ending Date</th>
           <th>Institute Name</th>
           <th>Institute City</th>
           <th>Salary</th>
           <th>Actions</th>
         </tr>
         <?php 
         $i=1;
           foreach ($data as $key) {
             echo '
               <tr>
                 <td>'.$key['jobTitle'].'</td>
                 <td>'.$key['startingDate'].'</td>
                 <td>'.$key['endingDate'].'</td>
                 <td>'.$key['instituteName'].'</td>
                 <td>'.$key['instituteCity'].'</td>
                 <td>'.$key['salary'].'</td>
                 <td>
                 <form action='.$updateProfessionUrl.' method="post" >
                  <input type="submit" name="edit" value="Edit" class="tableButton">
                  <input type="submit" name="delete" value="Delete" class="tableButton">
                  <input type="hidden" name="jobTitle" value='.$key['jobTitle'].'></form></td>
               </tr>';
               $i++;
         }
         ?>
         <br><br>
      </table>
	</div>
	</center>
</body>
</html>