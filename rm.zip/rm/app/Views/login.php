<?php
	$validateLoginUrl = (isset($url)) ? $url."Home/validateLogin" : "Home/validateLogin" ;
	$signupURL=(isset($url)) ? $url."Home/signup" : "Home/signup" ;
	$error=(isset($error)) ? $error : "" ;
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style type="text/css">
    	body{
			background-image: url('../images/bg.jpg');
			background-position: center;
			background-size: cover;
			color: white;
			font-family: sans-serif;
		}
		.footer{
			background: rgb(238, 238, 238,0.4);
			color: black;
			text-align: center;
			margin-top: 140px;
		}
    </style>
    </head>
    <body>
    	<center>
        <form action='<?php echo $validateLoginUrl?>' method='post' style='margin-top:200px;'>
			<fieldset style='border:3px dashed #d4d4d4; width: 200px; height: 200px' >

				<legend style="color: #d4d4d4;">Input Credentials</legend>
		<br>
		<input type='email' name='email' placeholder='Email' required><br><br>
		<input type='password' name='password' id="password" placeholder='Password' required><br>
		<input type="checkbox" onclick="showPassword()"><span style="color: #d4d4d4;">Show Password</span>
		<br><p style="color: red; font-size: 12px;"><?php echo $error;?></p>
		<input type='submit' value='Login' ></input>
		<br>
		<a href='<?php echo $signupURL;?>' style='color: #d4d4d4; font-weight: bold;'>Signup here</a>
		</fieldset>
		</form>
       </center>
       <footer>
			<div class='footer'>
				<h4>Asad Sarwar 051-18-0003 BSSE-6</h4>
				<p style='margin-top: -20px;'>email: asad.bse18@iba-suk.edu.pk</p>
			</div>
		</footer>
		<script type="text/javascript">
			function showPassword() {
			  var x = document.getElementById("password");
			  if (x.type === "password") {
			    x.type = "text";
			  } else {
			    x.type = "password";
			  }
			} 
		</script>
    </body>
</html>
