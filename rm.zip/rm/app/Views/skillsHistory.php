<?php
  //Setting up all the URLs for this page//////////
  $homeUrl = (isset($url)) ? $url."Home/main" : "Home/main" ;
  $educationUrl = (isset($url)) ? $url."Home/education" : "Home/education" ;
  $professionUrl = (isset($url)) ? $url."Home/profession" : "Home/profession" ;
  $skillsUrl = (isset($url)) ? $url."Home/skills" : "Home/skills" ;
  $pdfUrl = (isset($url)) ? $url."Home/pdf" : "Home/pdf" ;
  $logoutUrl = (isset($url)) ? $url."Home/logout" : "Home/logout" ;
  $updateSkillsUrl=(isset($url)) ? $url."Home/updateSkills" : "Home/updateSkills"
?>

<!DOCTYPE html>
<html>
<head>
	<title>Resume Maker</title>
    <link rel="stylesheet" type="text/css" href="../style/styleMain.css">
   
</head>
<body>
   <div class="topnav" id="myTopnav">
     <a href="<?php echo $homeUrl;?>" >Home</a>
     <a href="<?php echo $educationUrl;?>" >Education</a>
     <a href="<?php echo $professionUrl;?>">Profession</a>
     <a href="<?php echo $skillsUrl;?>" class="active">Skills</a>
     <a href="<?php echo $pdfUrl;?>" style="background-color: gray;">Get PDF</a>
   </div>
   <a href="<?php echo $logoutUrl;?>" class="tooltip"><span class="tooltiptext">Logout</span>Logout</a>
    <br><br><br>
	<center>
        <h1 style="color: black;">Current Records</h1>
	<div class="container">
      <table class="historyTable">
         <tr>
           <th>Skill Title</th>
           <th>Source of Learning</th>
           <th>Experties Level</th>
           <th>Practice Duration</th>
           <th>Actions</th>
         </tr>
         <?php 
         $i=1;
           foreach ($data as $key) {
             echo '
               <tr>
                 <td>'.$key['skillTitle'].'</td>
                 <td>'.$key['sourceOfLearning'].'</td>
                 <td>'.$key['expertiesLevel'].'</td>
                 <td>'.$key['practiceDuration'].'</td>
                 <td>
                 <form action='.$updateSkillsUrl.' method="post" >
                  <input type="submit" name="edit" value="Edit" class="tableButton">
                  <input type="submit" name="delete" value="Delete" class="tableButton">
                  <input type="hidden" name="skillTitle" value='.$key['skillTitle'].'></form></td>
               </tr>';
               $i++;
         }
         ?>
         <br><br>
      </table>
	</div>
	</center>
</body>
</html>