<?php
  //Setting up all the URLs for this page//////////
  $homeUrl = (isset($url)) ? $url."Home/main" : "Home/main" ;
  $educationUrl = (isset($url)) ? $url."Home/education" : "Home/education" ;
  $professionUrl = (isset($url)) ? $url."Home/profession" : "Home/profession" ;
  $skillsUrl = (isset($url)) ? $url."Home/skills" : "Home/skills" ;
  $pdfUrl = (isset($url)) ? $url."Home/pdf" : "Home/pdf" ;
  $logoutUrl = (isset($url)) ? $url."Home/logout" : "Home/logout" ;
  $generatePDFUrl=(isset($url)) ? "generatePDF" : "generatePDF" ;
  $name = (isset($_SESSION['name'])) ? $_SESSION['name'] : 'Logout' ;
  //dataEducation, dataProfession, dataSkills, dataPersonal
?>
<!DOCTYPE html>
<html>
<head>
	<title>Resume Maker</title>
    <link rel="stylesheet" type="text/css" href="../style/styleMain.css">

</head>
<body>
   <div class="topnav" id="myTopnav">
     <a href="<?php echo $homeUrl;?>" >Home</a>
     <a href="<?php echo $educationUrl;?>" >Education</a>
     <a href="<?php echo $professionUrl;?>">Profession</a>
     <a href="<?php echo $skillsUrl;?>">Skills</a>
     <a href="<?php echo $pdfUrl;?>" class="active">Get PDF</a>
   </div>
   <a href="<?php echo $logoutUrl;?>" class="tooltip"><span class="tooltiptext">Logout</span><?php echo ' '.$name; ?></a>
    <br>
    <center>
      <br><br>
      <h3 style="color: gray;">Personal Details</h3>
      <table class="historyTable">
         <tr>
           <th>NIC</th>
           <th>Email</th>
           <th>Country</th>
           <th>City</th>
           <th>Home address</th>
           <th>DoB</th>
           <th>Married</th>
           <th>Phone</th>
         </tr>
         <?php 
         $i=1;
           foreach ($dataPersonal as $key) {
             echo '
               <tr>
                 <td>'.$key['cnic'].'</td>
                 <td>'.$key['email'].'</td>
                 <td>'.$key['country'].'</td>
                 <td>'.$key['city'].'</td>
                 <td>'.$key['address'].'</td>
                 <td>'.$key['dob'].'</td>
                 <td>'.$key['maritalStatus'].'</td>
                 <td>'.$key['phone01'].'</td>
               </tr>';
               $i++;
         }
         ?>
         <br><br>
      </table><br>

      <h3 style="color: gray;">Education Details</h3>
      <table class="historyTable">
         <tr>
           <th>Level</th>
           <th>Starting Date</th>
           <th>Ending Date</th>
           <th>Institute Name</th>
           <th>Institute City</th>
           <th>Institute Country</th>
           <th>Obtained Grades</th>
           <th>Total Grades</th>
         </tr>
         <?php 
         $i=1;
           foreach ($dataEducation as $key) {
             echo '
               <tr>
                 <td>'.$key['level'].'</td>
                 <td>'.$key['startingDate'].'</td>
                 <td>'.$key['endingDate'].'</td>
                 <td>'.$key['instituteName'].'</td>
                 <td>'.$key['instituteCity'].'</td>
                 <td>'.$key['instituteCountry'].'</td>
                 <td>'.$key['obtainedGrades'].'</td>
                 <td>'.$key['totalGrades'].'</td>
               </tr>';
               $i++;
         }
         ?>
         <br><br>
      </table><br>

      <h3>Profession Details</h3>
      <table class="historyTable">
         <tr>
           <th>jobTitle</th>
           <th>Starting Date</th>
           <th>Ending Date</th>
           <th>Institute Name</th>
           <th>Institute City</th>
           <th>Salary</th>
         </tr>
         <?php 
         $i=1;
           foreach ($dataProfession as $key) {
             echo '
               <tr>
                 <td>'.$key['jobTitle'].'</td>
                 <td>'.$key['startingDate'].'</td>
                 <td>'.$key['endingDate'].'</td>
                 <td>'.$key['instituteName'].'</td>
                 <td>'.$key['instituteCity'].'</td>
                 <td>'.$key['salary'].'</td>
               </tr>';
               $i++;
         }
         ?>
         <br><br>
      </table><br>
      <h3>Skills</h3>
      <table class="historyTable">
         <tr>
           <th>Skill Title</th>
           <th>Source of Learning</th>
           <th>Experties Level</th>
           <th>Practice Duration</th>
         </tr>
         <?php 
         $i=1;
           foreach ($dataSkills as $key) {
             echo '
               <tr>
                 <td>'.$key['skillTitle'].'</td>
                 <td>'.$key['sourceOfLearning'].'</td>
                 <td>'.$key['expertiesLevel'].'</td>
                 <td>'.$key['practiceDuration'].'</td>
               </tr>';
               $i++;
         }
         ?>
         <br><br>
      </table>
<br><br><br>
    <form method="post" action="<?php echo $generatePDFUrl;?>">
      <input type="submit" name="generate" value="Generate PDF">
    </form>
</body>
</html>