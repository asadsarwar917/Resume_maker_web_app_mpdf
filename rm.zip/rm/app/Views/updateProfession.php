<?php
  //Setting up all the URLs for this page//////////
  $homeUrl = (isset($url)) ? $url."Home/main" : "Home/main" ;
  $educationUrl = (isset($url)) ? $url."Home/education" : "Home/education" ;
  $professionUrl = (isset($url)) ? $url."Home/profession" : "Home/profession" ;
  $skillsUrl = (isset($url)) ? $url."Home/skills" : "Home/skills" ;
  $pdfUrl = (isset($url)) ? $url."Home/pdf" : "Home/pdf" ;
  $logoutUrl = (isset($url)) ? $url."Home/logout" : "Home/logout" ;
  $name = (isset($_SESSION['name'])) ? $_SESSION['name'] : 'Logout' ;
  $saveUpdateProfessionUrl=(isset($url)) ? $url."Home/saveUpdateProfession" : "Home/saveUpdateProfession" ;
  $jobTitle = (isset($jobTitle)) ? $jobTitle : "" ;
?>

<!DOCTYPE html>
<html>
<head>
  <title>Resume Maker</title>
    <link rel="stylesheet" type="text/css" href="../style/styleMain.css">

</head>
<body>
   <div class="topnav" id="myTopnav">
     <a href="<?php echo $homeUrl;?>" >Home</a>
     <a href="<?php echo $educationUrl;?>" >Education</a>
     <a href="<?php echo $professionUrl;?>" class="active">Profession</a>
     <a href="<?php echo $skillsUrl;?>">Skills</a>
     <a href="<?php echo $pdfUrl;?>" style="background-color: gray;">Get PDF</a>
   </div>
   <a href="<?php echo $logoutUrl;?>" class="tooltip"><span class="tooltiptext">Logout</span><?php echo ' '.$name; ?></a>
    <br><br><br>
  <center>
        <h1 style="color: black;">Updating Record</h1>
  <div class="container">
        <div class="innerContainer">
            <div class="innerContainer2">
            <form action="<?php echo $saveUpdateProfessionUrl;?>" method="post" >
                    <h3 class="innerHeading">Professional Information</h3>
                  <label for="startingDate" >Starting Date</label>
                    <input type="date" name="startingDate" id="startingDate" required/><br>
                    <label for="endingDate" >Ending Date</label>
                    <input type="date" name="endingDate" id="endingDate" required/><br>
                    <label for="instituteName">Institute Name</label>
                    <input type="text" name="instituteName" id="instituteName" required><br>
                    <label for="InstituteCity">Institute City</label>
                    <input type="text" name="InstituteCity" id="InstituteCity" placeholder="Islamabad" required>
                  <br>
                    <label for="salary">Salary</label>
                    <input type="number" name="salary" id="salary" required>
                    <br>
                    <input type="hidden" name="jobTitle" id="jobTitle" value="<?php echo $jobTitle;?>">
                    <input class="reset" type="reset" value="Reset" id="reset" name="reset"  /> 
                  <br>
                    <input type="submit" value="Update" id="update" name="update" style="background-color: #c4ffc2;" />
                   <a href="<?php echo $professionUrl;?>"> <input type="button" value="Cancel" id="update" name="update" style="background-color: #ff8282;" /></a><br>
            </form>
            </div>
      </div>
  </div>
  </center>
</body>
</html>