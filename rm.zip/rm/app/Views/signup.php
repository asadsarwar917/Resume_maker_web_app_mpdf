<?php
	$saveSignupUrl=(isset($url)) ? $url."Home/saveSignup" : "Home/saveSignup" ;
	$loginUrl=(isset($url)) ? $url."Home" : "Home" ;
?>
<!DOCTYPE html>
<html>
<head>
	<title>SignUp</title>
	<link rel="stylesheet" type="text/css" href="../style/styleSignup.css">
</head>
<body>
	<header style="text-align: center;">
		<h1>Resume Maker</h1>
	</header>

<div class="container">
	<center>
	<h2>Registration</h2>
	</center>
	<div class="innerContainer">
	<form action="<?php echo $saveSignupUrl;?>" method="post">
		<label for="name">Full Name</label><br>
		<input type="text" id="name" name="name" placeholder="Asad Sarwar" required>
		<br>
		<label for="email">Email</label><br>
		<input type="email" id="email" name="email" placeholder="asadsarwar917@gmail.com" required>
		<br><br>
		<input type="password" id="password" name="password" placeholder="Password" required><br>
		<input type="password" id="rePassword" name="rePassword" placeholder="Repeat Password" oninput="matchPassword(this.value)" required>
		<br>
		<input type="submit" name="submit" value="Signup">
		<span>
		<input type="reset" name="reset" value="Reset" style="height: 20px; width: 50px;">
		</span>
	</form>
	</div>
	<a href="<?php echo $loginUrl;?>" style="color: white;">Go to Login</a>
</div>
	<script type="text/javascript">

		function matchPassword(pass) {
			if(document.getElementById('password').value != pass){
				document.getElementById('rePassword').style.color='red';
			}
			else{
				document.getElementById('rePassword').style.color='green';
			}
		}

	</script>
<footer>
	<div class="footer">
		<h4>Asad Sarwar 051-18-0003 BSSE-6</h4>
		<p style="margin-top: -20px;">email: asad.bse18@iba-suk.edu.pk</p>
	</div>
</footer>
</body>
</html>