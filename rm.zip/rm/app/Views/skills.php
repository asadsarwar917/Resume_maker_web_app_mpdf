<?php
  //Setting up all the URLs for this page//////////
  $homeUrl = (isset($url)) ? $url."Home/main" : "Home/main" ;
  $educationUrl = (isset($url)) ? $url."Home/education" : "Home/education" ;
  $professionUrl = (isset($url)) ? $url."Home/profession" : "Home/profession" ;
  $skillsUrl = (isset($url)) ? $url."Home/skills" : "Home/skills" ;
  $pdfUrl = (isset($url)) ? $url."Home/pdf" : "Home/pdf" ;
  $logoutUrl = (isset($url)) ? $url."Home/logout" : "Home/logout" ;
  $saveAsNewSkillsUrl = (isset($url)) ? $url."Home/saveAsNewSkills" : "Home/saveAsNewSkills" ;
  $updateSkillsUrl = (isset($url)) ? $url."Home/updateSkills" : "Home/updateSkills" ;
  
  $skillsHistoryUrl=(isset($url)) ? $url."Home/skillsHistory" : "Home/skillsHistory" ;

  $name = (isset($_SESSION['name'])) ? $_SESSION['name'] : 'Logout' ;
?>
<!DOCTYPE html>
<html>
<head>
	<title>Resume Maker</title>
    <link rel="stylesheet" type="text/css" href="../style/styleMain.css">

    <script>
    	function sliderValue(slider) {
    		document.getElementById("levelValue").innerHTML= slider.value;
    	}

	</script>
</head>
<body>
   <div class="topnav" id="myTopnav">
     <a href="<?php echo $homeUrl;?>" >Home</a>
     <a href="<?php echo $educationUrl;?>" >Education</a>
     <a href="<?php echo $professionUrl;?>">Profession</a>
     <a href="<?php echo $skillsUrl;?>" class="active">Skills</a>
     <a href="<?php echo $pdfUrl;?>" style="background-color: gray;">Get PDF</a>
   </div>
   <a href="<?php echo $logoutUrl;?>" class="tooltip"><span class="tooltiptext">Logout</span><?php echo ' '.$name; ?></a>
    <br><br><br>
	<center>
        <h1 style="color: black;">Fill Details Below</h1>
	<div class="container">
        <div class="innerContainer">
            <div class="innerContainer2">
        		<form action="<?php echo $saveAsNewSkillsUrl;?>" method="post" >
                    <h3 class="innerHeading">Skills Information</h3>
                    <label for="skillTitle">Skill Title</label>
                    <input type="text" name="skillTitle" id="skillTitle">
                    <br>
                    <label for="expertiesLevel">Experties Level: <span id="levelValue">5</span></label>
                    <input type="range" min="1" max="10" value="5" class="slider" oninput="sliderValue(this)" id="expertiesLevel" name="expertiesLevel"><br>
                    <label for="sourceOfLearning">Source of Learning</label>
                    <input type="text" name="sourceOfLearning" id="sourceOfLearning" required><br>
                    <label for="practiceDuration">Practice Duration</label>
                    <input type="text" name="practiceDuration" id="practiceDuration" required>
                	<br>
                    <input class="reset" type="reset" value="Reset" id="reset" name="reset"  /> 
                	<br>
                    <input type="submit" value="Save as New Record" id="update" name="update" style="background-color: #c4ffc2;" />
                   <a href="<?php echo $skillsHistoryUrl;?>"> <input type="button" value="Update Existing Record" id="update" name="update" style="background-color: #c4ffc2;" /></a><br>
        		</form>
            </div>
      </div>
	</div>
	</center>
</body>
</html>