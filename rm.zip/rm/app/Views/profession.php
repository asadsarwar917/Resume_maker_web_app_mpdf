<?php
  //Setting up all the URLs for this page//////////
  $homeUrl = (isset($url)) ? $url."Home/main" : "Home/main" ;
  $educationUrl = (isset($url)) ? $url."Home/education" : "Home/education" ;
  $professionUrl = (isset($url)) ? $url."Home/profession" : "Home/profession" ;
  $skillsUrl = (isset($url)) ? $url."Home/skills" : "Home/skills" ;
  $pdfUrl = (isset($url)) ? $url."Home/pdf" : "Home/pdf" ;
  $logoutUrl = (isset($url)) ? $url."Home/logout" : "Home/logout" ;
  $saveAsNewProfessionUrl = (isset($url)) ? $url."Home/saveAsNewProfession" : "Home/saveAsNewProfession" ;
  $updateProfessionUrl = (isset($url)) ? $url."Home/updateProfession" : "Home/updateProfession" ;
  $professionHistoryUrl=(isset($url)) ? $url."Home/professionHistory" : "Home/professionHistory" ;
  $name = (isset($_SESSION['name'])) ? $_SESSION['name'] : 'Logout' ;
?>
<!DOCTYPE html>
<html>
<head>
	<title>Resume Maker</title>
    <link rel="stylesheet" type="text/css" href="../style/styleMain.css">

</head>
<body>
   <div class="topnav" id="myTopnav">
     <a href="<?php echo $homeUrl;?>" >Home</a>
     <a href="<?php echo $educationUrl;?>" >Education</a>
     <a href="<?php echo $professionUrl;?>" class="active">Profession</a>
     <a href="<?php echo $skillsUrl;?>">Skills</a>
     <a href="<?php echo $pdfUrl;?>" style="background-color: gray;">Get PDF</a>
   </div>
   <a href="<?php echo $logoutUrl;?>" class="tooltip"><span class="tooltiptext">Logout</span><?php echo ' '.$name; ?></a>
    <br><br><br>
	<center>
        <h1 style="color: black;">Fill Details Below</h1>
	<div class="container">
        <div class="innerContainer">
            <div class="innerContainer2">
        		<form action="<?php echo $saveAsNewProfessionUrl;?>" method="post" >
                    <h3 class="innerHeading">Professional Information</h3>
                    <label for="jobTitle">Job Title/Post</label>
                    <input type="text" name="jobTitle" id="jobTitle" required><br>
                  <label for="startingDate" >Starting Date</label>
                    <input type="date" name="startingDate" id="startingDate" required/><br>
                    <label for="endingDate" >Ending Date</label>
                    <input type="date" name="endingDate" id="endingDate" required/><br>
                    <label for="instituteName">Institute Name</label>
                    <input type="text" name="instituteName" id="instituteName" required><br>
                    <label for="InstituteCity">Institute City</label>
                    <input type="text" name="InstituteCity" id="InstituteCity" placeholder="Islamabad" required>
                  <br>
                    <label for="salary">Salary</label>
                    <input type="number" name="salary" id="salary" required>
                    <br>
                    <input class="reset" type="reset" value="Reset" id="reset" name="reset"  /> 
                	<br>
                    <input type="submit" value="Save as New Record" id="update" name="update" style="background-color: #c4ffc2;" />
                   <a href="<?php echo $professionHistoryUrl;?>"> <input type="button" value="Update Existing Record" id="update" name="update" style="background-color: #c4ffc2;" /></a><br>
        		</form>
            </div>
      </div>
	</div>
	</center>
</body>
</html>