<?php
	namespace App\Models;
	use CodeIgniter\Model;

class ProfessionModel extends Model
{
	protected $table='profession';
	protected $primaryKey='id';
	protected $returnType='array';
	protected $allowedField=['email','jobTitle','startingDate','endingDate','instituteName','instituteCity','salary'];

	public function insert_data($data)
	{
		$sql = "INSERT INTO profession (email, jobTitle,startingDate,endingDate,instituteName,instituteCity,salary) VALUES (".$this->db->escape($data['email']).", ".$this->db->escape($data['jobTitle']).", ".$this->db->escape($data['startingDate']).", ".$this->db->escape($data['endingDate']).", ".$this->db->escape($data['instituteName']).", ".$this->db->escape($data['instituteCity']).", ".$this->db->escape($data['salary']).")";
		if ($this->db->query($sql)) {
			return true;
		}
		return false;
	}
	public function update_data($data)
	{
		$sql = "UPDATE profession SET startingDate=".$this->db->escape($data['startingDate']).",endingDate=".$this->db->escape($data['endingDate']).",instituteName=".$this->db->escape($data['instituteName']).",instituteCity=".$this->db->escape($data['instituteCity']).",salary=".$this->db->escape($data['salary'])." WHERE email=".$this->db->escape($data['email'])." AND jobTitle=".$this->db->escape($data['jobTitle'])."";
		if ($this->db->query($sql)) {
			return true;
		}
		return false;
	}

	public function deleteData($data)
	{
		$sql = "DELETE FROM profession WHERE email=".$this->db->escape($data['email'])." AND jobTitle=".$this->db->escape($data['jobTitle'])."";
	
		return $this->db->query($sql);
	}
}

?>