<?php
	namespace App\Models;
	use CodeIgniter\Model;

class EducationModel extends Model
{
	protected $table='education';
	protected $primaryKey='id';
	protected $returnType='array';
	protected $allowedField=['email','level','startingDate','endingDate','instituteName','instituteCity','instituteCountry','obtainedGrades','totalGrades'];

	public function insert_data($data)
	{
		$sql = "INSERT INTO education (email, level,startingDate,endingDate,instituteName,instituteCity,instituteCountry,obtainedGrades,totalGrades) VALUES (".$this->db->escape($data['email']).", ".$this->db->escape($data['level']).", ".$this->db->escape($data['startingDate']).", ".$this->db->escape($data['endingDate']).", ".$this->db->escape($data['instituteName']).", ".$this->db->escape($data['instituteCity']).", ".$this->db->escape($data['instituteCountry']).",".$this->db->escape($data['obtainedGrades']).", ".$this->db->escape($data['totalGrades']).")";
		return $this->db->query($sql);
	}

	public function update_data($data)
	{
		$sql = "UPDATE education SET startingDate=".$this->db->escape($data['startingDate']).",endingDate=".$this->db->escape($data['endingDate']).",instituteName=".$this->db->escape($data['instituteName']).",instituteCity=".$this->db->escape($data['instituteCity']).",instituteCountry=".$this->db->escape($data['instituteCountry']).",obtainedGrades=".$this->db->escape($data['obtainedGrades']).",totalGrades=".$this->db->escape($data['totalGrades'])." WHERE email=".$this->db->escape($data['email'])." AND level=".$this->db->escape($data['level'])."";
		
		return $this->db->query($sql);
		
	}

	public function deleteData($data)
	{
		$sql = "DELETE FROM education WHERE email=".$this->db->escape($data['email'])." AND level=".$this->db->escape($data['level'])."";
	
		return $this->db->query($sql);
	}

}

?>