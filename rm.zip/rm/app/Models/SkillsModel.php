<?php
	namespace App\Models;
	use CodeIgniter\Model;

class LoginModel extends Model
{
	protected $table='skills';
	protected $primaryKey='id';
	protected $returnType='array';
	protected $allowedField=['email','skillTitle','sourceOfLearning','expertiesLevel','practiceDuration'];

	public function insert_data($data)
	{
		$sql = "INSERT INTO skills (email, skillTitle,sourceOfLearning,expertiesLevel,practiceDuration) VALUES (".$this->db->escape($data['email']).", ".$this->db->escape($data['skillTitle']).", ".$this->db->escape($data['sourceOfLearning']).", ".$this->db->escape($data['expertiesLevel']).", ".$this->db->escape($data['practiceDuration']).")";

		return $this->db->query($sql);
	}
	public function update_data($data)
	{
		$sql = "UPDATE skills SET sourceOfLearning=".$this->db->escape($data['sourceOfLearning']).",expertiesLevel=".$this->db->escape($data['expertiesLevel']).",practiceDuration=".$this->db->escape($data['practiceDuration'])." WHERE email=".$this->db->escape($data['email'])." AND skillTitle=".$this->db->escape($data['skillTitle'])."";

		return $this->db->query($sql);
	}

	public function deleteData($data)
	{
		$sql = "DELETE FROM skills WHERE email=".$this->db->escape($data['email'])." AND skillTitle=".$this->db->escape($data['skillTitle'])."";
	
		return $this->db->query($sql);
	}
}

?>