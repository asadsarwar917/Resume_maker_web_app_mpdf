<?php
	namespace App\Models;
	use CodeIgniter\Model;

class LoginModel extends Model
{
	protected $table='user';
	protected $primaryKey='id';
	protected $returnType='array';
	protected $allowedField=['email','name','password','cnic','gender','dob','address','maritalStatus','phone01','phone02','city','country','bio'];

	public function insert_signup($data)
	{
		$sql = "INSERT INTO user (email, name,password) VALUES (".$this->db->escape($data['email']).", ".$this->db->escape($data['name']).", ".$this->db->escape($data['password']).")";
		if ($this->db->query($sql)) {
			return true;
		}
		return false;
	}

	public function update_personal_info($data)
	{
		$sql = "UPDATE user SET cnic=".$this->db->escape($data['cnic']).",gender=".$this->db->escape($data['gender']).",dob=".$this->db->escape($data['dob']).",address=".$this->db->escape($data['address']).",maritalStatus=".$this->db->escape($data['maritalStatus']).",phone01=".$this->db->escape($data['phone01']).",phone02=".$this->db->escape($data['phone02']).",city=".$this->db->escape($data['city']).",country=".$this->db->escape($data['country']).",bio=".$this->db->escape($data['bio'])." WHERE email=".$this->db->escape($data['email'])."";
		if ($this->db->query($sql)) {
			return true;
		}
		return false;
	}
}

?>