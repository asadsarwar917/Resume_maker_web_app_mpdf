<?php
	namespace App\Models;
	use CodeIgniter\Model;

class PersonalModel extends Model
{
	protected $table='user';
	protected $primaryKey='id';
	protected $returnType='array';
	protected $allowedField=['email','name','password','cnic','gender','dob','address','maritalStatus','phone01','phone02','city','country','bio'];

	
}

?>