<?php
	namespace App\Models;
	use CodeIgniter\Model;

class CurrentModel extends Model
{
	protected $table='current';
	protected $primaryKey='id';
	protected $returnType='array';
	protected $allowedField=['id','email'];
	
	public function insert_data($data)
	{
		$sql = "INSERT INTO current (email) VALUES (".$this->db->escape($data).")";
		$this->db->query($sql);
	}
	public function deleteData()
	{
		$sql = "DELETE FROM current";
		$this->db->query($sql);
	}
}

?>