-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 30, 2020 at 02:43 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `resume`
--

-- --------------------------------------------------------

--
-- Table structure for table `current`
--

CREATE TABLE `current` (
  `id` int(10) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `current`
--

INSERT INTO `current` (`id`, `email`) VALUES
(0, 'notasadsarwar@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `education`
--

CREATE TABLE `education` (
  `id` int(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `level` varchar(100) DEFAULT NULL,
  `startingDate` date DEFAULT NULL,
  `endingDate` date DEFAULT NULL,
  `instituteName` varchar(200) DEFAULT NULL,
  `instituteCity` varchar(100) DEFAULT NULL,
  `instituteCountry` varchar(100) DEFAULT NULL,
  `obtainedGrades` varchar(20) NOT NULL,
  `totalGrades` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `education`
--

INSERT INTO `education` (`id`, `email`, `level`, `startingDate`, `endingDate`, `instituteName`, `instituteCity`, `instituteCountry`, `obtainedGrades`, `totalGrades`) VALUES
(1, 'saifi@warraich.com', 'High School', '2013-04-01', '2015-04-01', 'Govt College', 'Multan', 'Pakistan', '82', '100'),
(2, 'saifi@warraich.com', 'Intermediate', '2015-05-01', '2017-03-01', 'Rise College', 'Multan', 'Pakistan', '3.5', '4'),
(3, 'asadsarwar917@gmail.com', 'High School', '2013-02-04', '2015-02-02', 'Govt. Colony high school', 'Rahimyar Khan', 'Pakistan', '785', '1100'),
(5, 'asadsarwar917@gmail.com', 'Intermediate', '2015-02-11', '2017-05-09', 'NICAAS College', 'Rahimyar Khan', 'Pakistan', '845', '1100'),
(6, 'notasadsarwar@gmail.com', 'High School', '2013-02-04', '2015-04-06', 'Govt. Colony high school', 'Rahimyar Khan', 'Pakistan', '785', '1100'),
(7, 'notasadsarwar@gmail.com', 'Intermediate', '2015-04-06', '2017-04-03', 'NICAAS College', 'Rahimyar Khan', 'Pakistan', '845', '1100');

-- --------------------------------------------------------

--
-- Table structure for table `profession`
--

CREATE TABLE `profession` (
  `id` int(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `jobTitle` varchar(100) NOT NULL,
  `startingDate` date NOT NULL,
  `endingDate` date NOT NULL,
  `instituteName` varchar(100) NOT NULL,
  `instituteCity` varchar(100) NOT NULL,
  `salary` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `profession`
--

INSERT INTO `profession` (`id`, `email`, `jobTitle`, `startingDate`, `endingDate`, `instituteName`, `instituteCity`, `salary`) VALUES
(1, 'saifi@warraich.com', 'Graphic Designer', '2019-01-01', '2020-01-01', 'Freelancer.com', 'at Home', 50000),
(4, 'asadsarwar917@gmail.com', 'Freelancing', '2019-03-01', '2020-12-01', 'home', 'Rahimyar Khan', 10000),
(5, 'notasadsarwar@gmail.com', 'Freelancing', '2019-02-05', '2020-12-30', 'home', 'Sukkur', 10000);

-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

CREATE TABLE `skills` (
  `id` int(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `skillTitle` varchar(200) NOT NULL,
  `sourceOfLearning` varchar(200) NOT NULL,
  `expertiesLevel` int(5) NOT NULL,
  `practiceDuration` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `skills`
--

INSERT INTO `skills` (`id`, `email`, `skillTitle`, `sourceOfLearning`, `expertiesLevel`, `practiceDuration`) VALUES
(1, 'saifi@warraich.com', 'Graphic Designing', 'Internet', 9, '2 years'),
(2, 'asadsarwar917@gmail.com', 'Web Designing', 'online and degree courses', 8, '1 year'),
(4, 'notasadsarwar@gmail.com', 'Graphic Designing', 'online courses', 8, '1 year');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `cnic` varchar(20) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `maritalStatus` varchar(20) DEFAULT NULL,
  `phone01` varchar(20) DEFAULT NULL,
  `phone02` varchar(20) DEFAULT NULL,
  `bio` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `email`, `name`, `password`, `cnic`, `gender`, `dob`, `address`, `city`, `country`, `maritalStatus`, `phone01`, `phone02`, `bio`) VALUES
(1, 'asadsarwar917@gmail.com', 'Asad Sarwar', '123', '3130369647205', 'male', '1998-08-03', 'Usman block-Abbasia Town', 'Rahimyar Khan', 'Pakistan', 'Single', '+923136100930', '', 'To put my abilities in a way which is best fit to the environment around me is my sole objective. I will try best to my skills and previous learnings to put them in improvement of assigned tasks.'),
(2, 'saifi@warraich.com', 'Saif Ibraheem', '123', '3421356789089', 'male', '2000-12-12', 'Shahi Muhal', 'Multan', 'Pakistan', 'Single', '+923012345567', '+923094556678', 'I am a student of Software Engineering at Sukkur IBA University. I love my field of study but I am more into graphic designing these days. I work to the best of my abilities and try to accomplilsh every task within the deadline.'),
(3, 'notasadsarwar@gmail.com', 'Asad Sarwar', '123', '3130369647205', 'male', '1998-08-03', 'Usman block-Abbasia Town', 'Rahimyar Khan', 'Pakistan', 'Single', '+923136100930', '', 'I am a student of software engineering at Sukkur IBA University. I like web designing and I am very much looking forward fro challenging projects in web.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `current`
--
ALTER TABLE `current`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `education`
--
ALTER TABLE `education`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profession`
--
ALTER TABLE `profession`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skills`
--
ALTER TABLE `skills`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `education`
--
ALTER TABLE `education`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `profession`
--
ALTER TABLE `profession`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `skills`
--
ALTER TABLE `skills`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
